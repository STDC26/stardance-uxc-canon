# sd-ui-canon

**SD UI Canon — Single Source of Truth for Stardance and Docente Surface Design**

Version: 1.0.0 · 2026-05-05  
UIS Version: 1.0 · 8th UXC Contract Layer  
Spec: [UIS + UXC Toolkit Specification · Notion](https://www.notion.so/3587a39590ff8193b7fed1afeff14a84)  
Status: PTC review pending · DRJ committed

---

## What This Repo Is

`sd-ui-canon` is the physical implementation layer of the UIS (UI Standard) — the 8th contract layer of the SD Unified Experience Contract. It contains every token, component, template, and tool that makes UIS compliance fast, consistent, and verifiable across SD, Docente, and MO-BASE surfaces.

**Governance:** Every file in this repo is canonized through the UXC. Changes require a DRJ ruling before merge.

---

## Structure

```
sd-ui-canon/
  tokens/
    sd-tokens.css           ← ALL theme × mode CSS variables (single source of truth)
  components/
    theme-switcher.js       ← Drop-in 3×3 theme/mode switcher with UIS compliance
    tooltip-system.css      ← Locked tooltip copy + above-positioning + left-anchor
    uat-feedback.js         ← UAT feedback drawer + Notion relay + session log
  templates/
    sd-surface.html         ← Canonical SD starting surface (UIS + UXC compliant)
    docente-surface.html    ← Docente starting surface (post-theme session)
    mo-base-surface.html    ← MO-BASE starting surface
  surfaces/
    approved/               ← UAT-passed, production-ready surfaces
    deferred/               ← Explored but not deployed — available for future use
    in-progress/            ← Currently in UAT
  tools/
    design-lab.html         ← 38-theme discovery tool
    uat-relay.html          ← Theme switcher UAT surface
  registry/
    canon.json              ← Version manifest — themes, modes, tooltip copy, rules
  README.md                 ← This file
```

---

## Quick Start

### 1. Import tokens and fonts

```html
<!-- Google Fonts — full SD canon font stack -->
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@300;400;500;600&family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@300;400;500&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&display=swap" rel="stylesheet">

<!-- SD token base -->
<link rel="stylesheet" href="path/to/sd-ui-canon/tokens/sd-tokens.css">
```

### 2. Add the theme switcher

```html
<!-- Switcher markup -->
<div class="palette-section">
  <div class="ps-label">Theme</div>
  <div class="ps-btns">
    <button data-palette="vega"  onclick="SD.handlePalette(this)" data-tooltip="Fifth brightest star in the night sky">Vega</button>
    <button data-palette="nova"  onclick="SD.handlePalette(this)" data-tooltip="A stellar explosion from a white dwarf star">Nova</button>
    <button data-palette="hydra" onclick="SD.handlePalette(this)" data-tooltip="The outermost moon of Pluto">Hydra</button>
  </div>
</div>
<div class="palette-section">
  <div class="ps-label">Mode</div>
  <div class="ps-btns">
    <button data-mode="dark"    onclick="SD.handleMode(this)" data-tooltip="Night sky · pure signal">Dark</button>
    <button data-mode="light"   onclick="SD.handleMode(this)" data-tooltip="Full spectrum · nothing hidden">Light</button>
    <button data-mode="classic" onclick="SD.handleMode(this)" data-tooltip="Amber glow · ideas first">Vibe</button>
  </div>
</div>

<!-- Tooltip + hover preview -->
<link rel="stylesheet" href="path/to/sd-ui-canon/components/tooltip-system.css">

<!-- Switcher logic -->
<script src="path/to/sd-ui-canon/components/theme-switcher.js"></script>
```

### 3. Start from a template

Copy the appropriate template from `templates/` and build from there. Every template is already UIS and UXC compliant — you add content, not infrastructure.

---

## UIS Rules (Summary)

| Rule | Value |
|---|---|
| Theme count | Must equal mode count · 3×3 canonical |
| Default theme | Vega |
| Default mode | Vibe |
| Theme naming | Astronomical · one naming system per product |
| Tooltip position | Above button · left-anchored · extends right · nowrap |
| Hover behaviour | Theme buttons accent to primary colour on hover |
| Creative mandate | 3 of 4: Motion · Depth · Character · Memory |
| Vanilla policy | **Vanilla is a UXC violation** |

---

## Locked Themes

| Theme | Primary | Fonts | Tooltip |
|---|---|---|---|
| **Vega** | #30ABCA | DM Sans / DM Mono | "Fifth brightest star in the night sky" |
| **Nova** | #E8751A | Syne / IBM Plex Mono | "A stellar explosion from a white dwarf star" |
| **Hydra** | #C8B89A · #1A1A1A | Syne / IBM Plex Mono | "The outermost moon of Pluto" |

## Locked Modes

| Mode | CSS key | Tooltip |
|---|---|---|
| **Dark** | `dark` | "Night sky · pure signal" |
| **Light** | `light` | "Full spectrum · nothing hidden" |
| **Vibe** | `classic` | "Amber glow · ideas first" |

---

## Surfaces Archive

### Approved (production-ready)
- `surfaces/approved/docente-cinematic-hero.html` — Docente CBC-01 Tier 3A · UAT full pass 2026-05-05

### In Progress
- `surfaces/in-progress/stardance-cinematic-hero.html` — SD CBC-01 Tier 3A · SVG logo pending

---

## Governance

**Changes to this repo require:**
- DRJ ruling for any modification to locked files (tokens, tooltip copy, theme/mode definitions)
- UAT relay validation before merging any surface changes
- PTC sign-off before new themes or modes are added
- DRJ gate for any Tier 3A components added to the surfaces archive

**Deferred themes (not in active stack):**
- Lyra (Aiiro Indigo & Rice · #1F4E8C) — Docente candidate · deferred pending theme session

---

## References

- [UIS + UXC Toolkit Specification (Notion)](https://www.notion.so/3587a39590ff8193b7fed1afeff14a84)
- [SD Theme Switcher Standard · UXC v1.3 Appendix (Notion)](https://www.notion.so/3577a39590ff8163b043e1c04e786904)
- [SD Theme Switcher LOCKED (Notion)](https://www.notion.so/3577a39590ff814dacc2d3ffc135a63e)
- [Creative Differentiation Mandate (Notion)](https://www.notion.so/3587a39590ff81ada5a8d9d8df1f95f3)
- UAT Relay: uat-relay-production.up.railway.app
- Design Lab: docente-frontend-production.up.railway.app/design-lab.html

---

*sd-ui-canon v1.0.0 · 2026-05-05 · DTC authored · PTC governed · DRJ executed*
